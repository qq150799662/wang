module.exports = {
  root: true,
  presets: [
    [
      '@babel/env',
      {
        modules: false,
      },
    ],
  ],
}

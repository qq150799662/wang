export function installToast() {
  // @TODO
}

import { ref } from 'vue'

export const showAppsSelector = ref(true)

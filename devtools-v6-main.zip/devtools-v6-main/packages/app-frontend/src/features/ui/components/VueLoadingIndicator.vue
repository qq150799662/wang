<template>
  <div class="vue-ui-loading-indicator">
    <div class="animation" />
    <slot />
  </div>
</template>

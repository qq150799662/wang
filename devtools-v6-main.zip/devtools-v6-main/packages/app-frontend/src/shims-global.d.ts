// @TODO remove
declare const browser: any

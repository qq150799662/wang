<script>
export default {

}
</script>

<template>
  <h2>Child route</h2>
</template>

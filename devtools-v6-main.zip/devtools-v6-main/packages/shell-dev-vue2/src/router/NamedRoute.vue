<script>
export default {
}
</script>

<template>
  <div>
    <p>Hello named route</p>
  </div>
</template>

<script>
export default {

}
</script>

<template>
  <div class="parent">
    <h2>Parent</h2>
    <router-view class="child" />
  </div>
</template>

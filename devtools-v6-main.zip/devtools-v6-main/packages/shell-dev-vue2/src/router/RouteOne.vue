<script>
export default {

}
</script>

<template>
  <div>
    <p>Hello from route 1</p>
  </div>
</template>

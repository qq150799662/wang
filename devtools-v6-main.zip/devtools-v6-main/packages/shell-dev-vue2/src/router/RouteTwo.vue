<script>
export default {

}
</script>

<template>
  <div>
    <p>Hello from route 2</p>
  </div>
</template>

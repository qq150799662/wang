<script>
export default {
}
</script>

<template>
  <div>
    <p>Hello from before enter route</p>
  </div>
</template>

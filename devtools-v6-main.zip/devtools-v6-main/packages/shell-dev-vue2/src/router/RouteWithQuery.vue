<script>
export default {
}
</script>

<template>
  <div>
    <p>Hello from route with query: {{ $route.query }}</p>
  </div>
</template>

<script>
export default {
  name: 'FormSection',
}
</script>

<template>
  <fieldset>
    <legend>Form section</legend>
    <slot />
  </fieldset>
</template>

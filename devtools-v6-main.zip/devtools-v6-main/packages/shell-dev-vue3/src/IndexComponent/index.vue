<template>
  <h2>Index component</h2>
</template>

import { installHook } from '@back/hook'
import { target } from '@vue-devtools/shared-utils'

installHook(target)

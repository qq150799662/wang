#!/bin/bash

rm -rf icons

cp -r ../shell-chrome/icons .
cp -r ../shell-chrome/popups .
cp ../shell-chrome/*.html .
